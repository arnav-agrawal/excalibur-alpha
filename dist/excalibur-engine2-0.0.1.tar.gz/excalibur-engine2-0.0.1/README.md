![EXCALIBUR logo](Excalibur_logo.png)

# EXCALIBUR

An open-source project for calculating molecular and atomic cross sections for exoplanet atmospheres.
